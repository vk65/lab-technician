//
//  APIConstants.swift
//  Lab techinans
//
//  Created by Sambav on 22/06/22.
//

import Foundation

struct BASEURL {
    static let QA = "https://dev.sambav.com/"
}

struct APIConstants {
    static let baseUrl = BASEURL.QA
    static let loginPath = "api/registration/UserValidate"
    static let orderList = "api/lab/GetGeneralLabOrders"
    static let changePassword = "api/lab/UpdateLabTechnicianDetails"
    static let uploadImage = "api/lab/uploadsamplesM"
    static let getProficPic = "api/common/ProfileImage?"
}
