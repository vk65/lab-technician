//
//  API Handler.swift
//  Sambav Health
//
//  Created by Sambav on 05/11/21.
//

import Foundation
import UIKit

class APIHandler {
    
    static let shared = APIHandler()
    private init() { }
    typealias onCompletionHandler = (Any?, Error?) -> Void
    
    func POSTService<Element: Codable>(path : String, postString : [String: Any], responseType: Element.Type, completion : @escaping onCompletionHandler) {
        
        guard let url = URL(string: "\(APIConstants.baseUrl)\(path)") else { return }
        let parameters = try? JSONSerialization.data(withJSONObject: postString, options: [])
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        urlRequest.httpBody = parameters
        let defaultSessionConfiguration = URLSessionConfiguration.default
        defaultSessionConfiguration.httpAdditionalHeaders = [
            "isError": UserDefaults.standard.string(forKey: "IsError") ?? "",
            "latlon": UserDefaults.standard.string(forKey: "LatLong") ?? ""]
        _ = URLSession(configuration: defaultSessionConfiguration)
        urlRequest.setValue(UserDefaults.standard.string(forKey: "userToken") ?? "", forHTTPHeaderField: "Authorization")

        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        print("Url: \(url), parameters: \(String(describing: parameters)) & postString: \(postString)")
        
        URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            guard  let httpResponse = response as? HTTPURLResponse else {
                completion(nil, APIFailure.noResponse)
                return
            }
            print("StatusCode", httpResponse.statusCode)
            if error != nil {
                completion(nil, error)
            } else {
                do {
                    guard let dataIs = data else {
                        completion(nil, APIFailure.noData)
                        return
                    }
                    
                    if httpResponse.statusCode == 400 {
                        let serverResponse1 = try JSONSerialization.jsonObject(with: dataIs, options: .allowFragments)
                        let dates = serverResponse1 as! [String:Any]
                        let error = NSError(domain: "", code: httpResponse.statusCode, userInfo: [NSLocalizedDescriptionKey: dates["error_description"] ?? ""])
                        completion(nil, error)
                    }
                                        
                    let serverResponse1 = try JSONSerialization.jsonObject(with: dataIs, options: .allowFragments)
                    print("Responses: \(serverResponse1)")
                    
                    let serverResponse = try JSONDecoder().decode(responseType, from: dataIs)
                    completion(serverResponse, nil)
                } catch {
//                    print(error.localizedDescription)
                    print(String(describing: error))
                    completion(nil, error)
                }
            }
        }.resume()
    }
    
    func GETService<Element: Codable>(path:String, responeType: Element.Type, completion:@escaping onCompletionHandler)
    {
        guard let url = URL(string: "\(APIConstants.baseUrl)\(path)") else { return }
        //let parameters = try? JSONSerialization.data(withJSONObject: postString, options: [])
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "GET"
        let defaultSessionConfiguration = URLSessionConfiguration.default
        defaultSessionConfiguration.httpAdditionalHeaders = [
            "isError": UserDefaults.standard.string(forKey: "IsError") ?? "",
            "latlon": UserDefaults.standard.string(forKey: "LatLong") ?? ""]
        _ = URLSession(configuration: defaultSessionConfiguration)
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        urlRequest.setValue(UserDefaults.standard.string(forKey: "userToken") ?? "", forHTTPHeaderField: "Authorization")
        print("Url: \(url)")
        URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            guard  let httpResponse = response as? HTTPURLResponse else {
                completion(nil, APIFailure.noResponse)
                return
            }
            print("StatusCode", httpResponse.statusCode)
            if error != nil {
                completion(nil, error)
            } else {
                do {
                    guard let dataIs = data else {
                        completion(nil, APIFailure.noData)
                        return
                    }
                    
                    if httpResponse.statusCode == 400 {
                        let serverResponse1 = try JSONSerialization.jsonObject(with: dataIs, options: .allowFragments)
                        let dates = serverResponse1 as! [String:Any]
                        let error = NSError(domain: "", code: httpResponse.statusCode, userInfo: [NSLocalizedDescriptionKey: dates["error_description"] ?? ""])
                        completion(nil, error)
                    }
                                        
                    let serverResponse1 = try JSONSerialization.jsonObject(with: dataIs, options: .allowFragments)
                    print("Responses: \(serverResponse1)")
                    
//                    do {
                        let decoder = JSONDecoder()
                        let decoded = try decoder.decode(responeType.self, from: dataIs)
                        print("Responses decode: \(decoded)")
                        completion(decoded, nil)

//                    } catch {
                        // print(localizedDescription) // <- ⚠️ Don't use this!
//                        print(String(describing: error)) // <- ✅ Use this for debuging!
//                    }

                } catch {
//                    print(error.localizedDescription)
                    print(String(describing: error)) // <- ✅ Use this for debuging!
                    completion(nil, error)
                }
            }
        }.resume()
  }
    
    func deleteAPIService(path: String, completion:@escaping onCompletionHandler) {
        guard let url = URL(string: "\(APIConstants.baseUrl)\(path)") else { return }
        //let parameters = try? JSONSerialization.data(withJSONObject: postString, options: [])
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "GET"
        let defaultSessionConfiguration = URLSessionConfiguration.default
        defaultSessionConfiguration.httpAdditionalHeaders = [
            "isError": UserDefaults.standard.string(forKey: "IsError") ?? "",
            "latlon": UserDefaults.standard.string(forKey: "LatLong") ?? ""]
        _ = URLSession(configuration: defaultSessionConfiguration)
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        urlRequest.setValue(UserDefaults.standard.string(forKey: "userToken") ?? "", forHTTPHeaderField: "Authorization")
        print("Url: \(url)")
        URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            guard  let httpResponse = response as? HTTPURLResponse else {
                completion(nil, APIFailure.noResponse)
                return
            }
            print("StatusCode", httpResponse.statusCode)
            if error != nil {
                completion(nil, error)
            } else {
                do {
                    guard let dataIs = data else {
                        completion(nil, APIFailure.noData)
                        return
                    }
                    
                    if httpResponse.statusCode == 400 {
                        let serverResponse1 = try JSONSerialization.jsonObject(with: dataIs, options: .allowFragments)
                        let dates = serverResponse1 as! [String:Any]
                        let error = NSError(domain: "", code: httpResponse.statusCode, userInfo: [NSLocalizedDescriptionKey: dates["error_description"] ?? ""])
                        completion(nil, error)
                    }
                                        
                    let serverResponse1 = try JSONSerialization.jsonObject(with: dataIs, options: .allowFragments)
                    completion(serverResponse1, nil)
                    print("Responses: \(serverResponse1)")
                    
                } catch {
                    print(error.localizedDescription)
                    completion(nil, error)
                }
            }
        }.resume()
    }
    
    
    func postAPIService(path: String, httpMethod: String, completion:@escaping onCompletionHandler) {
        guard let url = URL(string: "\(APIConstants.baseUrl)\(path)") else { return }
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = httpMethod
        let defaultSessionConfiguration = URLSessionConfiguration.default
        defaultSessionConfiguration.httpAdditionalHeaders = [
            "isError": UserDefaults.standard.string(forKey: "IsError") ?? "",
            "latlon": UserDefaults.standard.string(forKey: "LatLong") ?? ""]
        _ = URLSession(configuration: defaultSessionConfiguration)
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        urlRequest.setValue(UserDefaults.standard.string(forKey: "userToken") ?? "", forHTTPHeaderField: "Authorization")
        print("Url: \(url)")
        URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            guard  let httpResponse = response as? HTTPURLResponse else {
                completion(nil, APIFailure.noResponse)
                return
            }
            print("StatusCode", httpResponse.statusCode)
            if error != nil {
                completion(nil, error)
            } else {
                do {
                    guard let dataIs = data else {
                        completion(nil, APIFailure.noData)
                        return
                    }
                    
                    if httpResponse.statusCode == 400 {
                        let serverResponse1 = try JSONSerialization.jsonObject(with: dataIs, options: .allowFragments)
                        let dates = serverResponse1 as! [String:Any]
                        let error = NSError(domain: "", code: httpResponse.statusCode, userInfo: [NSLocalizedDescriptionKey: dates["error_description"] ?? ""])
                        completion(nil, error)
                    }
                                        
                    let serverResponse1 = try JSONSerialization.jsonObject(with: dataIs, options: .allowFragments)
                    completion(serverResponse1, nil)
                    print("Responses: \(serverResponse1)")
                    
                } catch {
                    print(error.localizedDescription)
                    completion(nil, error)
                }
            }
        }.resume()

    }
    
    func POSTServiceWithParameters(path : String, postString : [String: Any], completion : @escaping onCompletionHandler) {
        guard let url = URL(string: "\(APIConstants.baseUrl)\(path)") else { return }
        let parameters = try? JSONSerialization.data(withJSONObject: postString, options: [])
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        urlRequest.httpBody = parameters
        urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
        let defaultSessionConfiguration = URLSessionConfiguration.default
        defaultSessionConfiguration.httpAdditionalHeaders = [
            "isError": UserDefaults.standard.string(forKey: "IsError") ?? "",
            "latlon": UserDefaults.standard.string(forKey: "LatLong") ?? ""]
        _ = URLSession(configuration: defaultSessionConfiguration)
        urlRequest.setValue(UserDefaults.standard.string(forKey: "userToken") ?? "", forHTTPHeaderField: "Authorization")
        print("Url: \(url), parameters: \(String(describing: parameters)) & postString: \(postString)")
        URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            guard  let httpResponse = response as? HTTPURLResponse else {
                completion(nil, APIFailure.noResponse)
                return
            }
            print("StatusCode", httpResponse.statusCode)
            if error != nil {
                completion(nil, error)
            } else {
                do {
                    guard let dataIs = data else {
                        completion(nil, APIFailure.noData)
                        return
                    }
                    
                    if httpResponse.statusCode == 400 {
                        let serverResponse1 = try JSONSerialization.jsonObject(with: dataIs, options: .allowFragments)
                        let dates = serverResponse1 as! [String:Any]
                        let error = NSError(domain: "", code: httpResponse.statusCode, userInfo: [NSLocalizedDescriptionKey: dates["error_description"] ?? ""])
                        completion(nil, error)
                    }
                                        
                    let serverResponse1 = try JSONSerialization.jsonObject(with: dataIs, options: .allowFragments)
                    print("Responses: \(serverResponse1)")
                    completion(serverResponse1, nil)
                } catch {
                    print(error.localizedDescription)
                    completion(nil, error)
                }
            }
        }.resume()
    }
}




/*
func GETService<Element: Codable>(path:String, responeType: Element.Type, completion:@escaping onCompletionHandler)
{
    guard let url = URL(string: "\(APIConstants.baseUrl)\(path)") else { return }
    //let parameters = try? JSONSerialization.data(withJSONObject: postString, options: [])
    var urlRequest = URLRequest(url: url)
    urlRequest.httpMethod = "GET"
    let defaultSessionConfiguration = URLSessionConfiguration.default
    defaultSessionConfiguration.httpAdditionalHeaders = [
        "isError": UserDefaults.standard.string(forKey: "IsError") ?? "",
        "latlon": UserDefaults.standard.string(forKey: "LatLong") ?? ""]
    _ = URLSession(configuration: defaultSessionConfiguration)
    urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
    urlRequest.setValue(UserDefaults.standard.string(forKey: "userToken") ?? "", forHTTPHeaderField: "Authorization")
    print("Url: \(url)")
    URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
        guard  let httpResponse = response as? HTTPURLResponse else {
            completion(nil, APIFailure.noResponse)
            return
        }
        print("StatusCode", httpResponse.statusCode)
        if error != nil {
            completion(nil, error)
        } else {
            do {
                guard let dataIs = data else {
                    completion(nil, APIFailure.noData)
                    return
                }
                
                if httpResponse.statusCode == 400 {
                    let serverResponse1 = try JSONSerialization.jsonObject(with: dataIs, options: .allowFragments)
                    let dates = serverResponse1 as! [String:Any]
                    let error = NSError(domain: "", code: httpResponse.statusCode, userInfo: [NSLocalizedDescriptionKey: dates["error_description"] ?? ""])
                    completion(nil, error)
                }
                                    
                let serverResponse1 = try JSONSerialization.jsonObject(with: dataIs, options: .allowFragments)
                print("Responses: \(serverResponse1)")
                
                let serverResponse = try JSONDecoder().decode(responeType.self, from: dataIs)
                completion(serverResponse, nil)
                
                print("Responses: \(serverResponse)")

            } catch {
                print(error.localizedDescription)
                completion(nil, error)
            }
        }
    }.resume()
}
*/
