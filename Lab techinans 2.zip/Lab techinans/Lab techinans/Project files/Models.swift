//
//  Models.swift
//  Lab techinans
//
//  Created by Sambav on 22/06/22.
//

import Foundation
import UIKit

struct LoginResponse: Codable {
    let accessToken, tokenType: String!
    let expiresIn:Int!
    //let labID, ltid: Int!
    let asClientID, globalID, email, userType: String!
    let userID, fullName, mobile, subscriptionTypeID: String!
    let userName, isFirstLogIn, createdOn, vailidityDays: String!
    let errorURI, orgID, isKid, imagePath: String!
    let trailExpiry, cc, ce, cp: String!
    let device, issued, expires: String!
    enum CodingKeys: String, CodingKey {
        case accessToken = "access_token"
        case tokenType = "token_type"
        case expiresIn = "expires_in"
        case asClientID = "as:client_id"
        case globalID = "GlobalID"
        case email, userType
        case userID = "userId"
        case fullName, mobile, subscriptionTypeID = ""
        case userName = "UserName"
        case isFirstLogIn, createdOn, vailidityDays
        case errorURI = "error_uri"
        case orgID = "OrgID"
        case isKid = "IsKid"
        case imagePath = "name"
        case trailExpiry = "TrailExpiry"
        case cc =  "IN"
        case ce = "91"
        case cp = "patient.profile"
        case device = "Device"
        case issued = ".issued"
        case expires = ".expires"
       // case labId = "labID"
       // case ltid = "ltid"
    }
}


enum LoginFailureType:String {
    case error
    case error_description
    case error_uri
    case Expired
    case emptyEmail
    case emptyPassword
    case emptyDOB
    case doubleResult
    case invalidOTP
    case recordsNotFound
    case invalidQRCOde
}


enum APIFailure: Error {
    case noResponse
    case noData
}


struct SideMenuModel {
    var icon: UIImage?
    var title: String?
}


struct serviceForGetTime: Codable {
    let dstOffset, isError, rawOffset, timestamp: Int?
}

struct OrderList:Codable{
    let id, patientID, labID: Int?
    let referredBy, createdOn, updatedOn: String?
    let packageID: Int?
    let ltid, type: Int
    let testIDs: String?
    let packageFee: Int?
    let packageName: String?
    let labTests, orderID, checksum: String?
    let isExternal: Bool?
    let name, userName, phoneNumber: String
    let paymentStatus: Int?
    let orderType, uid: String?
    let orderStatus: String?
    let pinCode: String?
    let bt: String?
    let isActive: Bool?
    let cityID, stateID: Int?
    let tests, salt, password: String?
    let setP: Bool?
    let labOrderStatus: Int?
    let path:String?
}

struct ChangeDetails:Codable{
    let code:Int?
    let id:Int?
    let message:String?
    let mobile:String?
    let value:String?
}

struct ForgotResponse: Codable {
    let id, userID: Int?
    let name, userName: String?
    let otp: String?
    let isActive: Bool?
    let createdDate: String?
    let createdBy, result: Int?
    let isError: Bool?
    let message: String?
    let userIDIdentity: Int?
    let isKid: Bool?
    let securityID: Int?
    let questionAnswer, email, mobileNumber: String?
    let otpType, age: Int?
    let countryEXT: String?
    let hasFamilyCode: Bool?
    let familyMembers: [String]?

    enum CodingKeys: String, CodingKey {
        case id, userID, name, userName, otp, isActive, createdDate, createdBy, result, isError, message, userIDIdentity, isKid, securityID, questionAnswer, email, mobileNumber, otpType, age
        case countryEXT = "countryExt"
        case hasFamilyCode, familyMembers
    }
}


struct ProfilePicture: Codable {
    let userTypeID, userID: Int
    let imageData: String?
    let userImage: String
    let imagePath: String
    let folderName: String?
    let createdOn: String

    enum CodingKeys: String, CodingKey {
        case userTypeID = "userTypeId"
        case userID = "userId"
        case imageData, userImage, imagePath, folderName, createdOn
    }
}
