//
//  SHCollectionViewCell.swift
//  Pods
//
//  Created by 母利 睦人 on 2017/01/04.
//
//

import UIKit

class SHCollectionViewCell: UICollectionViewCell {
    @IBOutlet var filterNameLabel: UILabel!
    @IBOutlet var imageView: UIImageView!
}
