//
//  ForgotPasswordViewController.swift
//  Lab Technician
//
//  Created by Sambav on 01/07/22.
//

import UIKit

class ForgotPasswordViewController: UIViewController, UITextFieldDelegate {

    var jsonData = [String:Any]()
    @IBOutlet weak var emailTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        //MARK: - View Controller Life Cycle
        emailTextField.delegate = self
        emailTextField.addBottomBorder()
        self.hideKeyboardOnTapAround()
        // Do any additional setup after loading the view.
    }
    
    override func viewDidLayoutSubviews() {
        emailTextField.addBottomBorder()
    }
    

    //MARK: - KEYBOARD-DISMISS METHOD
        func hideKeyboardOnTapAround() {
            let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.hideKeyboard))
            tap.cancelsTouchesInView = false
            self.view.addGestureRecognizer(tap)
        }

        @objc func hideKeyboard() {
            self.view.endEditing(true)
        }
    
    //MARK: - TEXTFIELD DELEGATE METHODS
        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
               self.view.endEditing(true)
               return false
           }
       
       func textFieldDidBeginEditing(_ textField: UITextField) {
           if textField == emailTextField {
               textField.addBlueColor()
           }
       }
   
       func textFieldDidEndEditing(_ textField: UITextField) {
           if textField == emailTextField {
               textField.addBottomBorder()
           }
       }

    //MARK: - Valid Email address
    func isValidEmail(testStr:String) -> Bool {
              print("validate emilId: \(testStr)")
              let emailRegEx = "^(?:(?:(?:(?: )*(?:(?:(?:\\t| )*\\r\\n)?(?:\\t| )+))+(?: )*)|(?: )+)?(?:(?:(?:[-A-Za-z0-9!#$%&’*+/=?^_'{|}~]+(?:\\.[-A-Za-z0-9!#$%&’*+/=?^_'{|}~]+)*)|(?:\"(?:(?:(?:(?: )*(?:(?:[!#-Z^-~]|\\[|\\])|(?:\\\\(?:\\t|[ -~]))))+(?: )*)|(?: )+)\"))(?:@)(?:(?:(?:[A-Za-z0-9](?:[-A-Za-z0-9]{0,61}[A-Za-z0-9])?)(?:\\.[A-Za-z0-9](?:[-A-Za-z0-9]{0,61}[A-Za-z0-9])?)*)|(?:\\[(?:(?:(?:(?:(?:[0-9]|(?:[1-9][0-9])|(?:1[0-9][0-9])|(?:2[0-4][0-9])|(?:25[0-5]))\\.){3}(?:[0-9]|(?:[1-9][0-9])|(?:1[0-9][0-9])|(?:2[0-4][0-9])|(?:25[0-5]))))|(?:(?:(?: )*[!-Z^-~])*(?: )*)|(?:[Vv][0-9A-Fa-f]+\\.[-A-Za-z0-9._~!$&'()*+,;=:]+))\\])))(?:(?:(?:(?: )*(?:(?:(?:\\t| )*\\r\\n)?(?:\\t| )+))+(?: )*)|(?: )+)?$"
              let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
              let result = emailTest.evaluate(with: testStr)
              return result
          }

//MARK: - UIBUTTON METHODS
    @IBAction func backButtonAction(_ sender: Any) {
        let loginVC = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        loginVC.modalPresentationStyle = .fullScreen
        //navigationController?.pushViewController(homeVC, animated: true)
        self.present(loginVC, animated: true, completion: nil)
    }
    
    
    @IBAction func submitBtnAction(_ sender: Any) {
        let emailOrMobileString = self.emailTextField.text!
        view.endEditing(true)
        NetWorkMonitor.shared.monitor { (success) -> (Void) in
        
        if success == true {
            //DispatchQueue.main.async {
             //   MBProgressHUD.showAdded(to: self.view, animated: true)
          //  }
            let url1:String = APIConstants.changePassword
//            let range:NSRange = str.range(of: "@")
            let emailrange = NSString(string: emailOrMobileString).range(of: "@", options: String.CompareOptions.caseInsensitive)
            let mobilerange = NSString(string: emailOrMobileString).range(of: "0123456789", options: String.CompareOptions.caseInsensitive)

            if emailrange.location != NSNotFound {
            // it is an email
                self.jsonData = [
                "EmailId" : emailOrMobileString,
                "MobileNumber" : "",
                "IdCradOrAadharNumber" : "",
                "Otp" : ""
                ] }
            if (emailOrMobileString.rangeOfCharacter(from: CharacterSet(charactersIn: "0123456789")) != nil)
            {
                self.jsonData = [
                    "EmailId" : "",
                    "MobileNumber" : emailOrMobileString,
                    "IdCradOrAadharNumber" : "",
                    "Otp" : ""]
           }
            else if mobilerange.location != NSNotFound {
                // it is a phone
                self.jsonData = [
                    "EmailId" : "",
                    "MobileNumber" : emailOrMobileString,
                    "IdCradOrAadharNumber" : "",
                    "Otp" : ""]
            }
            var jsonString: String? = nil
                if let jsonData:Data = self.jsonData as? Data{
                jsonString = String(data: jsonData, encoding: .utf8)
            }

            // Convert POST string parameters to data using UTF8 Encoding
            let postParams = "\(jsonString ?? "")"
            _ = postParams.data(using: .utf8)
                APIHandler.shared.POSTService(path: url1, postString: self.jsonData, responseType: ChangeDetails.self) { result, error in
                
                    DispatchQueue.main.async {
                        if error == nil {
                            if let response = result as? ChangeDetails{
                                _ = [response]
                                //finally hide it, whether its sucess or failure just remove it
                                if (response.code! > 0){
                                   
                                }
                                else
                                {
                                    let alertController = UIAlertController(title: "Lab Technician", message: "Not a valid User", preferredStyle: .alert)
                                    let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                                    alertController.addAction(ok)
                                    self.present(alertController, animated: true)
                                }
                            }
                        }
                       // MBProgressHUD.hide(for: self.view, animated: true)
                    }
            }

        }  else
      {
          DispatchQueue.main.async {
              let alertController = UIAlertController(title: "Lab Technician", message: "Connection Error", preferredStyle: .alert)
                 let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                 alertController.addAction(ok)
              self.present(alertController, animated: true)
          }
      }
    }



    }
    
    @IBAction func cancelBtnAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}
