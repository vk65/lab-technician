//
//  OrdersViewController.swift
//  Lab techinans
//
//  Created by Sambav on 24/06/22.
//

import UIKit
import Photos

class OrdersViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UIViewControllerTransitioningDelegate, UISearchBarDelegate, UITextFieldDelegate {
    
    @IBOutlet weak var searchButton: UIButton!
    @IBOutlet weak var searchView: UIView!
    var ordersArray = [OrderList]()
    var mobilenumberArray = [OrderList]()
    var uidArray = [OrderList]()
    var fromDateArray = [OrderList]()
    var toDateArray = [OrderList]()
    lazy var filteredOrderedArray = self.ordersArray
    var jsonDictionary = [String:Any]()
    var imageOrStatusString: String!
    let radioController: RadioButtonController = RadioButtonController()
    var pickerImgString:String!
    var base64String:String!
    var idArray = [String]()
    var jsonArray = [OrderList]()
    var fromDateOrToDateString:String!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var blankImageview: UIImageView!
    @IBOutlet weak var orderStatusView: UIView!
    @IBOutlet weak var ordersTableView: UITableView!
    var imagePicker = UIImagePickerController()
    @IBOutlet weak var labGenerateBtn: UIButton!
    var passId:String!
    var labID:String!
    var imageFilledId:String!
    
    @IBOutlet weak var searchMobileNumberTextField: UITextField!
    
    @IBOutlet weak var searchUIDTextField: UITextField!
    
    @IBOutlet weak var searchToDateTextfield: UITextField!
    
    @IBOutlet weak var searchFromDateTextField: UITextField!
    
    @IBOutlet weak var searchBackBtn: UIButton!
    @IBOutlet weak var searchSubmitBtn: UIButton!
    var serverfromDate: String?
    var servertoDate:String?
    @IBOutlet weak var toDateBtn: UIButton!
    @IBOutlet weak var fromDateBtn: UIButton!
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var dateView: UIView!
    @IBOutlet weak var searchCancelBtn: UIButton!
    @IBOutlet weak var sampleLabBtn: UIButton!
    @IBOutlet weak var samplesBtn: UIButton!
    @IBOutlet weak var btAssignedBtn: UIButton!
    @IBOutlet weak var cancelledBtn: UIButton!
    @IBOutlet weak var orderUploadedBtn: UIButton!
    @IBOutlet weak var NotAvailableBtn: UIButton!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var okBtn: UIButton!
    let activityIndicator = ActivityIndicator()
    var statusId:String!
    var btnString:String!
    var searchController : UISearchController!
    var searching:Bool!
    var fromDate: Date!
    var toDate: Date!
    var dateFormatter:DateFormatter!
    var firstTimeFromDateValue: Bool!
    var firstTimeToDateValue: Bool!
    //MARK: - View Controller Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        dateView.isHidden = true
        dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEEE, MMMM dd, yyyy"
        datePicker.maximumDate = Date()
        firstTimeFromDateValue = true
        firstTimeToDateValue = true
        serviceForGetOrders()
        ordersTableView.reloadData()
        orderStatusView.isHidden = true
        blankImageview.isHidden = true
        radioController.buttonsArray = [labGenerateBtn,sampleLabBtn,samplesBtn,btAssignedBtn,cancelledBtn,orderUploadedBtn, NotAvailableBtn ]
        radioController.defaultButton = labGenerateBtn
        searchView.isHidden = true
        searchMobileNumberTextField.delegate = self
        searchUIDTextField.delegate = self
        searchFromDateTextField.delegate = self
        searchToDateTextfield.delegate = self
        NotAvailableBtn.setImage(UIImage(named: "unselected"), for: .normal)
        cancelledBtn.setImage(UIImage(named: "unselected"), for: .normal)
        orderUploadedBtn.setImage(UIImage(named: "unselected"), for: .normal)
        labGenerateBtn.setImage(UIImage(named: "unselected"), for: .normal)
        samplesBtn.setImage(UIImage(named: "unselected"), for: .normal)
        sampleLabBtn.setImage(UIImage(named: "unselected"), for: .normal)
        btAssignedBtn.setImage(UIImage(named: "unselected"), for: .normal)
        cancelBtn.layer.cornerRadius = 5
        cancelBtn.clipsToBounds = true
        okBtn.layer.cornerRadius = 5
        okBtn.clipsToBounds = true
        searchControllerSetup()
        //view.setNeedsDisplay()
        //view.snapshotView(afterScreenUpdates: true)
        hideKeyboardOnTapAround()
        // Do any additional setup after loading the view.
    }
    
    //MARK: - Search controller
     func searchControllerSetup(){
          searchController = UISearchController(searchResultsController: nil)
          navigationItem.searchController = searchController
          navigationItem.hidesSearchBarWhenScrolling = false
      }
      
    
    override func viewDidLayoutSubviews() {
        searchUIDTextField.addBottomBorder()
        searchMobileNumberTextField.addBottomBorder()
        searchFromDateTextField.addBottomBorder()
        searchToDateTextfield.addBottomBorder()
    }

    
    //MARK: - KEYBOARD-DISMISS METHOD
    func hideKeyboardOnTapAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.hideKeyboard))
        tap.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tap)
    }

    @objc func hideKeyboard() {
        self.view.endEditing(true)
    }
    
    //MARK: - TEXTFIELD DELEGATE METHODS
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
   
    //MARK: - UIButton
    @IBAction func backButtonAction(_ sender: Any) {
        self.view.addSubview(self.activityIndicator)
        let menuViewController = storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        menuViewController.modalPresentationStyle = UIModalPresentationStyle.custom
        menuViewController.transitioningDelegate = self
        menuViewController.view.backgroundColor = .clear
        let transition = CATransition()
        transition.duration = 0.3
        transition.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        transition.type = CATransitionType.push
        transition.subtype = CATransitionSubtype.fromLeft
        view.window!.layer.add(transition, forKey: nil)
        present(menuViewController, animated: false)
        self.activityIndicator.hide()
    }
    
    @IBAction func searchButtonAction(_ sender: Any) {
        if searchView.isHidden {
            searchView.isHidden = false
            orderStatusView.isHidden = true
            blankImageview.isHidden = true
            } else {
                searchView.isHidden = true
                orderStatusView.isHidden = true
                blankImageview.isHidden = true
            }
    }
    
    
    @IBAction func fromDateBtnAction(_ sender: Any) {
        fromDateOrToDateString = "fromDate"
        view.endEditing(true)
        dateView.isHidden = false
    }
    
    @IBAction func toDateBtnAction(_ sender: Any) {
        fromDateOrToDateString = "toDate"
        view.endEditing(true)
        dateView.isHidden = false
    }
    
    
    @IBAction func clearBtnAction(_ sender: Any) {
        searchMobileNumberTextField.text = nil
        searchUIDTextField.text = nil
        searchFromDateTextField.text = nil
        searchToDateTextfield.text = nil
        searchView.isHidden = true
        serviceForGetOrders()
        fromDateOrToDateString = "fromDate"
        ordersTableView.reloadData()
        searching = false
    }
    
    
    @IBAction func searchBackBtnAction(_ sender: Any) {
        searchView.isHidden = true
    }
    
    
    @IBAction func searchBtnAction(_ sender: Any) {
        print("hello")
        searching = true
        
        jsonArray.removeAll()
//        if searchMobileNumberTextField.text!.count == 0 || searchUIDTextField.text!.count == 0 || searchFromDateTextField.text!.count == 0 || searchToDateTextfield.text!.count == 0 {
//            jsonArray.append(contentsOf: ordersArray)
//            view.endEditing(true)
//            } else {
//                let substring = searchMobileNumberTextField.text!
//                for item in ordersArray {
//                    let mobileNumber = item.phoneNumber
//                    let stringRange = (mobileNumber as NSString?)?.range(of: substring, options: .caseInsensitive)
//
//                    if stringRange?.location != NSNotFound {
//                        jsonArray.append(item)
//                    }
//                }
//            }
        
        var matches:[OrderList]!
        var matchesUID:[OrderList]!
        var matchesFromDate:[OrderList]!
        var matchesToDate:[OrderList]!
                for item in ordersArray {
                let mobileNum = searchMobileNumberTextField.text!
                let itemMobileNum = item.phoneNumber
                let stringUID = searchUIDTextField.text!
                let itemStringUID = item.userName
                let stringFromDate = searchFromDateTextField.text!
                let itemStringFromDate = item.createdOn
                let stringToDate = searchToDateTextfield.text!
                let itemStringToDate = item.updatedOn
                let stringRange = (mobileNum as NSString?)?.range(of: itemMobileNum, options: .caseInsensitive)
                let stringRangeUID = (stringUID as NSString?)?.range(of: itemStringUID, options: .caseInsensitive)
                let dateformat = DateFormatter()
                dateformat.timeZone = NSTimeZone(name: "UTC") as TimeZone?
                dateformat.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS"
                let usDate = dateformat.date(from: itemStringFromDate ?? "")
                let upDate = dateformat.date(from: itemStringToDate ?? "")
                dateformat.dateFormat = "dd-MM-yyyy"
                var strDate1: String? = nil
                var update2: String? = nil
                guard let usDate = usDate else{return}
                strDate1 = dateformat.string(from: usDate)
                guard let upDate = upDate else{return}
                update2 = dateformat.string(from: upDate)
                let stringRangeFromDate = (stringFromDate as NSString?)?.range(of: strDate1!, options: .caseInsensitive)
                let stringRangeToDate = (stringToDate as NSString?)?.range(of: update2!, options: .caseInsensitive)


                if mobileNum.count == 0 && stringUID.count == 0 && stringFromDate.count == 0 && stringToDate.count == 0{
                    jsonArray.append(contentsOf:ordersArray)
                    jsonArray.append(item)

                } else {
                    
                    //matches = ordersArray.contains(where: { $0.phoneNumber == item.phoneNumber })
                    
                   
                   // matches = ordersArray.filter({$0.phoneNumber.lowercased().prefix(mobileNum.count) == mobileNum.lowercased()})
                    matches = ordersArray.filter {
                                $0.phoneNumber.lowercased().contains(mobileNum.lowercased())
                            }
                        
                    
                    matchesUID = ordersArray.filter {
                        $0.userName.lowercased().contains(stringUID.lowercased())
                    }
                   // matchesFromDate = ordersArray.filter({$0.createdOn!.lowercased().prefix(itemStringFromDate!.count) == itemStringFromDate!.lowercased()})
                    let deFormatter = DateFormatter()
                    deFormatter.timeZone = NSTimeZone(name: "UTC") as TimeZone?
                    //deFormatter.locale = Locale(identifier: "en_US_POSIX") // set locale to reliable US_POSIX
                    
                    //if  stringFromDate.isEmpty == true{
                        deFormatter.dateFormat = stringFromDate
                       let date = deFormatter.date(from: stringFromDate)
                   // }else{
                      //  deFormatter.dateFormat = stringToDate
                       //  date = deFormatter.date(from: stringToDate)
                   // }
                    let dateString = deFormatter.string(from: date!)
                    let usDate = dateformat.date(from: dateString )
                    deFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS"
                    var strDate: String? = nil
                    if let usDate = usDate {
                        strDate = deFormatter.string(from: usDate)
                    }
                    //if let uploadedDate = uploadedDate {
                    //    uprDate = deFormatter.string(from: uploadedDate)
                    //}
                    let trimmedString = strDate?.split(separator: "T")
                   // var uploadTrimmedString = uprDate?.split(separator: "T")
                    //stringArray = ordersArray.filter{$0.createdOn?.lowercased()}
//                    var dateForm = item.createdOn?.split(separator: "T")
//                    var dateForm1 = dateForm![0]
                    if trimmedString != nil{
                    matchesFromDate = ordersArray.filter {
                        $0.createdOn!.contains(trimmedString![0].lowercased())
                    }
                    }else{
                        matchesFromDate = ordersArray.filter {
                            $0.createdOn!.contains(stringToDate.lowercased())
                        }
                    }
                
                    
//                    let upFormatter = DateFormatter()
//                    upFormatter.timeZone = NSTimeZone(name: "UTC") as TimeZone?
//                    let upDate = deFormatter.date(from: stringToDate)
//                    let upDateString = deFormatter.string(from: upDate!)
//                    let upDate1 = dateformat.date(from: upDateString )
//                    upFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS"
//                    var upDate2: String? = nil
//                    if let upDate1 = upDate1 {
//                        upDate2 = deFormatter.string(from: upDate1)
//                    }
//
//                    let updateTrimmedString = upDate2?.split(separator: "T")
//                    dateChanges(str: matchesToDate)
                    
                    matchesToDate = ordersArray.filter( { $0.updatedOn!.range(of: stringToDate, options: .caseInsensitive) != nil})
                    
                    if matchesToDate.count == 0{
                        jsonArray.append(item)
                    }else{
                        matchesToDate = ordersArray.filter {
                            $0.updatedOn!.contains(stringToDate.lowercased())
                        }
                    }
//                    matchesToDate = ordersArray.filter {
//                        //if matchesToDate != nil{
//                        $0.updatedOn!.lowercased().contains(stringToDate.lowercased())
//                        //}else{
//                           // matchesToDate = ordersArray.filter{$0.createdOn}
//                        //}
//                }

                   // if mobileNum.count != 0 && stringUID.count != 0 && stringFromDate.count != 0 && stringToDate.count != 0

//                    for matche in matchesUID{
//                     if stringRangeUID?.location != NSNotFound  {
//                         jsonArray.append(matche)
//                    }
//                    }
//                    for matchFrom in matchesFromDate{
//                    if stringRangeFromDate?.location != NSNotFound {
//                        jsonArray.append(matchFrom)
//                    }
//                    }
//
//                    for matchTo in matchesToDate{
//                    if stringRangeToDate?.location != NSNotFound {
//                        jsonArray.append(matchTo)
//                    }
//                    }

                   // }
                }
                }
           
                   //if stringRange!.location != NSNotFound  {
                    for match in matches{
                        jsonArray.append(match)
                     //}
                    }
        
                            for matche in matchesUID{
                             //if stringRangeUID?.location != NSNotFound  {
                                 jsonArray.append(matche)
                            //}
                            }
                            for matchFrom in matchesFromDate{
                            //if stringRangeFromDate?.location != NSNotFound {
                                jsonArray.append(matchFrom)
                            //}
                            }

                            for matchTo in matchesToDate{
                            //if stringRangeToDate?.location != NSNotFound {
                                jsonArray.append(matchTo)
                            //}
                            }
////                    if stringUID.count == 0{
////                        ordersArray.append(contentsOf:jsonArray)
////                    } else {
////
////                        let stringRange = (stringUID as NSString?)?.range(of: itemStringUID, options: .caseInsensitive)
////                        if stringRange?.location != NSNotFound {
////                            ordersArray.append(item)
////                        }
////                        }
//////
////                    let dateformat = DateFormatter()
////                    dateformat.timeZone = NSTimeZone(name: "UTC") as TimeZone?
////                    dateformat.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS"
////                    let usDate = dateformat.date(from: itemStringFromDate ?? "")
////                    let upDate = dateformat.date(from: itemStringToDate ?? "")
////                    dateformat.dateFormat = "dd-MM-yyyy"
////                    var strDate1: String? = nil
////                    var update2: String? = nil
////                    if let usDate = usDate {
////                    strDate1 = dateformat.string(from: usDate)
////                    if let upDate = upDate{
////                    update2 = dateformat.string(from: upDate)
////                    if stringFromDate.count == 0{
////                        ordersArray.append(contentsOf:jsonArray)
////                    } else {
////                        let stringRange = (stringFromDate as NSString?)?.range(of: strDate1!, options: .caseInsensitive)
////                        if stringRange?.location != NSNotFound {
////                            ordersArray.append(item)
////                        }
////                        }
////                    }
////
////                    if stringFromDate.count == 0{
////                        ordersArray.append(contentsOf:jsonArray)
////                    } else {
////                        let stringRange = (stringToDate as NSString?)?.range(of: update2!, options: .caseInsensitive)
////                        if stringRange?.location != NSNotFound {
////                            ordersArray.append(item)
////                        }
////                        }
////                    }
//               //}
//
//
//
//
//
//
////                if substringUID.count == 0{
////                    ordersArray.append(contentsOf:jsonArray)
////                } else {
////                    for item in jsonArray {
////
////                        if (((substringUID as NSString?)?.range(of: item.userName, options: .caseInsensitive)) != nil) {
////                            uidArray.append(contentsOf: jsonArray)
////                            ordersArray.append(contentsOf: uidArray)
////                        }
////                    }
////                }
////
////                if substringFromDate.count != 0{
////                    ordersArray.append(contentsOf:jsonArray)
////                } else {
////                    for item in jsonArray {
////                        if (((substringUID as NSString?)?.range(of: item.userName, options: .caseInsensitive)) != nil) {
////                            uidArray.append(contentsOf: jsonArray)
////                            ordersArray.append(contentsOf: uidArray)
////                        }
////                    }
////                }
//
//
//
//
////                 for item in jsonArray {
////                let mobileNumber = item.phoneNumber as? String
////                let uid = item.userName as? String
////                let date = item.createdOn as? String
////                let updatedOn = item.updatedOn as? String
////                let dateformat = DateFormatter()
////                dateformat.timeZone = NSTimeZone(name: "UTC") as TimeZone?
////                dateformat.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS"
////                let usDate = dateformat.date(from: date ?? "")
////                let upDate = dateformat.date(from: updatedOn ?? "")
////                dateformat.dateFormat = "dd-MM-yyyy"
////                var strDate1: String? = nil
////                var update2: String? = nil
////                if let usDate = usDate {
////                strDate1 = dateformat.string(from: usDate)
////                if let upDate = upDate{
////                update2 = dateformat.string(from: upDate)
////                let stringRange = (mobileNumber as NSString?)?.range(of: substring, options: .caseInsensitive)
////                let stringRangeUid = (uid as NSString?)?.range(of: substringUID, options: .caseInsensitive)
////                let stringRangeCreatedOn = (strDate1 as NSString?)?.range(of: substringFromDate, options: .caseInsensitive)
////                let stringRangeUpdatedOn = (update2 as NSString?)?.range(of: substringToDate, options: .caseInsensitive)
////                if stringRange!.location != NSNotFound || stringRangeUid!.location != NSNotFound || stringRangeCreatedOn!.location != NSNotFound || stringRangeUpdatedOn!.location != NSNotFound {
////                    ordersArray.append(item)
////                }
////                }
////                    }
////
////
////        }
//
       //}
            ordersTableView.reloadData()
            searchView.isHidden = true

        }
        
    
    
    
    @IBAction func dateCancelBtnAction(_ sender: Any) {
        dateView.isHidden = true
    }
    
    @IBAction func dateDoneBtnAction(_ sender: Any) {
        if fromDateOrToDateString == "fromDate" {
            fromDate = dateFormatter.date(from: dateFormatter.string(from: datePicker.date))
            
            serverfromDate = "\(dateFormatter.string(from: datePicker.date))"
            //india
            let format = DateFormatter()
            format.dateFormat = "dd-MM-yyyy"
            let uploadDt = format.string(from: datePicker.date)
            
            if firstTimeFromDateValue == true {
                firstTimeToDateValue = false
                dateView.isHidden = true
               // fromDateBtn.setTitle(uploadDt, for: .normal)
                searchFromDateTextField.text = uploadDt
            } else {
                switch fromDate.compare(toDate) {
                case ComparisonResult.orderedAscending:
                    
                    //NSLog(@"NSOrderedAscending");
                    self.firstTimeToDateValue = false
                    self.dateView.isHidden = true
                   // self.fromDateBtn.setTitle(uploadDt, for: .normal)
                    searchToDateTextfield.text = uploadDt
                    break
                    
                case ComparisonResult.orderedSame:
                    
                    let alertController = UIAlertController(title: "Health Wallet", message: "Select Valid Date", preferredStyle: .alert)
                    let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alertController.addAction(ok)
                    present(alertController, animated: true)
                    break
                    
                case ComparisonResult.orderedDescending:
                    let alertController = UIAlertController(title: "Health Wallet", message: "Select Valid Date", preferredStyle: .alert)
                    let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alertController.addAction(ok)
                    present(alertController, animated: true)
                    break
                }
            }
        }
        else {
            toDate = dateFormatter.date(from: dateFormatter.string(from: datePicker.date))
            
            servertoDate = "\(dateFormatter.string(from: datePicker.date))"
            //india
            let format = DateFormatter()
            format.dateFormat = "dd-MM-yyyy"
            let uploadDt = format.string(from: datePicker.date)
            
            if firstTimeToDateValue == true {
                firstTimeFromDateValue = false
                dateView.isHidden = true
                //toDateButton.setTitle(uploadDt, for: .normal)
                searchToDateTextfield.text = uploadDt
            }
            else {
                switch toDate.compare(fromDate) {
                case ComparisonResult.orderedAscending:
                    //NSLog(@"NSOrderedAscending");
                    let alertController = UIAlertController(title: "Health Wallet", message: "Select Valid Date", preferredStyle: .alert)
                    let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alertController.addAction(ok)
                    present(alertController, animated: true)
                    break
                case ComparisonResult.orderedSame:
                    let alertController = UIAlertController(title: "Health Wallet", message: "Select Valid Date", preferredStyle: .alert)
                    let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alertController.addAction(ok)
                    present(alertController, animated: true)
                    break
                case ComparisonResult.orderedDescending:
                    firstTimeFromDateValue = false
                    dateView.isHidden = true
                   // toDateButton.setTitle(uploadDt, for: .normal)
                    searchToDateTextfield.text = uploadDt
                    break
                }
            }
        }
    }
    
    
    
    
    //MARK: - TableViewDelegate Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searching == true{
            return jsonArray.count
        }
        else{
          return ordersArray.count
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = tableView.dequeueReusableCell(withIdentifier: "OrdersTableViewCell") as? OrdersTableViewCell
        if cell == nil {
            cell = OrdersTableViewCell(style: .default, reuseIdentifier: nil)
        }
        let result:[OrderList]!

        if searching == true{
            result = jsonArray
            //ordersTableView.reloadData()
        }
        else{
            result = ordersArray
            //ordersTableView.reloadData()
        }

        cell?.selectionStyle = .none
        let dateString = "\(result[indexPath.row].createdOn ?? "")"
        let dateformat = DateFormatter()
        dateformat.timeZone = NSTimeZone(name: "UTC") as TimeZone?
        dateformat.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS"
        let usDate = dateformat.date(from: dateString )
        dateformat.dateFormat = "dd-MM-yyyy"
        var strDate: String? = nil
        if let usDate = usDate {
            strDate = dateformat.string(from: usDate)
        }
        cell?.orderDateLbl.text = "Order Date:  \(String(describing: strDate ?? ""))"
        
        let object = result[indexPath.row].packageID ?? 0
            if   object <= 0 {
                cell?.packageLbl.text = "Package:  Lab tests"
            }
            else {
                cell?.packageLbl.text = "Package:  LabPackage(\(String(describing: result[indexPath.row].packageName ?? "")))"
            }
        

        cell?.nameLabel.text = "Name:  \(String(describing: result[indexPath.row].name ))"
        cell?.uidLabel.text = "UID:  \(String(describing: result[indexPath.row].userName ))"
        cell?.nameLabel.text = "Name:  \(String(describing: result[indexPath.row].name ))"
        cell?.mobileLabel.text = "Mobile Number:  \(String(describing: result[indexPath.row].phoneNumber ))"
       
        if let object = result[indexPath.row].labOrderStatus{
            if "\(object)" == "2"{
                cell?.labOrderStatusLbl.text = "LaborderStatus : Lab Order Generated"
            }
            else if "\(object)" == "7"{
                cell?.labOrderStatusLbl.text = "LaborderStatus : Not Available"
            }
            else if "\(object)" == "8"{
                cell?.labOrderStatusLbl.text = "LaborderStatus : OrderUploaded"
            }
            else if "\(object)" == "9"{
                cell?.labOrderStatusLbl.text = "LaborderStatus : Cancelled"
            }
            else if "\(object)" == "10"{
                cell?.labOrderStatusLbl.text = "LaborderStatus : BT Assigned"
            }
            else if "\(object)" == "11"{
                cell?.labOrderStatusLbl.text = "LaborderStatus : Samples Collected"
            }
            else {
                cell?.labOrderStatusLbl.text = "LaborderStatus : Samples Sent To Lab"
            }
        }

        if let object = result[indexPath.row].paymentStatus{
            if "\(object)" == "1"{
                cell?.paymentLabel.text = "Payment Type : Payment initiated"
            }
            else if "\(object)" == "2"{
                cell?.paymentLabel.text = "Payment Type:  Online"
            }
            else {
                cell?.paymentLabel.text = "Payment Type:  Offline"
            }
        }
        cell?.uploadBtn.layer.cornerRadius = 5
        cell?.uploadBtn.clipsToBounds = true
        cell?.uploadStatusBtn.layer.cornerRadius = 5
        cell?.uploadStatusBtn.clipsToBounds = true
        cell?.viewSampleBtn.layer.cornerRadius = 5
        cell?.viewSampleBtn.clipsToBounds = true
        cell?.uploadBtn.addTarget(self, action: #selector(uploadImageAction(sender:)), for: UIControl.Event.touchUpInside)
        cell?.uploadStatusBtn.addTarget(self, action: #selector(updateStatus(_:)), for: UIControl.Event.touchUpInside)
//        if ordersArray[indexPath.row].path == ""{
//        cell?.viewSampleBtn.isEnabled = false
//        }else{
//        cell?.viewSampleBtn.isEnabled = true
        cell?.viewSampleBtn.addTarget(self, action: #selector(viewSample(_:)), for: UIControl.Event.touchUpInside)
       // }
        cell?.orderTypeLabel.text = "Order Type:  \(String(describing: result[indexPath.row].orderStatus ?? ""))"
        
        return cell!
    }


    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 255
    }
    
    
    @objc func uploadImageAction(sender: UIButton)
    {
        let button = sender as? UIButton
        let cell = button?.superview?.superview as? UITableViewCell
        let indexPath = ordersTableView.indexPath(for: cell!)
        print(indexPath!.row)
        for i in 0..<ordersArray.count{
        if indexPath?.row == i{
        passId = "\(String(describing: ordersArray[i].patientID ?? 0))"
        labID = "\(String(describing:ordersArray[i].id ?? 0))"
        //print(passId ?? "")
        print(labID ?? "")
        }
        }
        let alert = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Take Photo", style: .default, handler: { _ in
            self.openCamera()
        }))
        
        alert.addAction(UIAlertAction(title: "Choose Photo", style: .default, handler: { _ in
            self.openGallary()
        }))
        
        alert.addAction(UIAlertAction.init(title: "Cancel", style: .cancel, handler: nil))
        
        //If you want work actionsheet on ipad then you have to use popoverPresentationController to present the actionsheet, otherwise app will crash in iPad
        switch UIDevice.current.userInterfaceIdiom {
        case .pad:
            alert.popoverPresentationController?.sourceView = sender
            alert.popoverPresentationController?.sourceRect = sender.bounds
            alert.popoverPresentationController?.permittedArrowDirections = .up
        default:
            break
        }
        
        self.present(alert, animated: true, completion: nil)

    }
    
    //MARK: - Open the camera
    func openCamera(){
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerController.SourceType.camera)){
            imagePicker.sourceType = UIImagePickerController.SourceType.camera
            //If you dont want to edit the photo then you can set allowsEditing to false
            imagePicker.allowsEditing = true
            imagePicker.delegate = self
            self.present(imagePicker, animated: true, completion: nil)
        }
        else{
            let alert  = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    //MARK: - Choose image from camera roll
    func openGallary(){
        imagePicker.sourceType = UIImagePickerController.SourceType.photoLibrary
        //If you dont want to edit the photo then you can set allowsEditing to false
        imagePicker.allowsEditing = true
        imagePicker.delegate = self
        self.present(imagePicker, animated: true, completion: nil)
    }

    
    @objc func updateStatus(_ sender: UIButton)
    {
        orderStatusView.isHidden = false
        blankImageview.isHidden = false
        searchView.isHidden = true
        btnString = "status"
        let button = sender as? UIButton
        let cell = button?.superview?.superview as? UITableViewCell
        let indexPath = ordersTableView.indexPath(for: cell!)
        print(indexPath!.row)
        for i in 0..<ordersArray.count{
        if indexPath?.row == i{
        passId = "\(String(describing: ordersArray[i].patientID ?? 0))"
        labID = "\(ordersArray[i].id ?? 0)"
            print(labID ?? "")
        }
        }
    }
    
    @objc func viewSample(_ sender: UIButton)
    {
        let button = sender as? UIButton
        let cell = button?.superview?.superview as? UITableViewCell
        let indexPath = ordersTableView.indexPath(for: cell!)
        print(indexPath!.row)
        for i in 0..<ordersArray.count{
        if indexPath?.row == i{
        view.addSubview(self.activityIndicator)
        if ordersArray[i].path == ""{
            let alertController = UIAlertController(title: "Lab Technician", message: "Samples Not Uploaded!", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(ok)
            self.present(alertController, animated: true, completion: nil)
        }else{
        let viewSample = storyboard?.instantiateViewController(withIdentifier: "OrdersWebviewViewController") as! OrdersWebviewViewController
        viewSample.url = ordersArray[i].path ?? ""
        viewSample.modalPresentationStyle = .fullScreen
        present(viewSample, animated: true, completion: nil)
        self.activityIndicator.hide()
        }
        }
        }
    }
    
    

    //MARK: - UIBUTTON
    @IBAction func labGenerationBtnAction(_ sender: UIButton) {
        radioController.buttonArrayUpdated(buttonSelected: sender)
        statusId = "2"
        print(statusId ?? "")
        labGenerateBtn.setImage(UIImage(named: "selected"), for: .normal)
        NotAvailableBtn.setImage(UIImage(named: "unselected"), for: .normal)
        cancelledBtn.setImage(UIImage(named: "unselected"), for: .normal)
        orderUploadedBtn.setImage(UIImage(named: "unselected"), for: .normal)
        btAssignedBtn.setImage(UIImage(named: "unselected"), for: .normal)
        samplesBtn.setImage(UIImage(named: "unselected"), for: .normal)
        sampleLabBtn.setImage(UIImage(named: "unselected"), for: .normal)
    }
    
    @IBAction func notAvailableBtnAction(_ sender: UIButton) {
        radioController.buttonArrayUpdated(buttonSelected: sender)
        statusId = "7"
        print(statusId ?? "")
        labGenerateBtn.setImage(UIImage(named: "unselected"), for: .normal)
        NotAvailableBtn.setImage(UIImage(named: "selected"), for: .normal)
        cancelledBtn.setImage(UIImage(named: "unselected"), for: .normal)
        orderUploadedBtn.setImage(UIImage(named: "unselected"), for: .normal)
        btAssignedBtn.setImage(UIImage(named: "unselected"), for: .normal)
        samplesBtn.setImage(UIImage(named: "unselected"), for: .normal)
        sampleLabBtn.setImage(UIImage(named: "unselected"), for: .normal)
    }
    
    @IBAction func cancelledBtnAction(_ sender: UIButton) {
        radioController.buttonArrayUpdated(buttonSelected: sender)
        statusId = "9"
        print(statusId ?? "")
        cancelledBtn.setImage(UIImage(named: "selected"), for: .normal)
        NotAvailableBtn.setImage(UIImage(named: "unselected"), for: .normal)
        labGenerateBtn.setImage(UIImage(named: "unselected"), for: .normal)
        orderUploadedBtn.setImage(UIImage(named: "unselected"), for: .normal)
        btAssignedBtn.setImage(UIImage(named: "unselected"), for: .normal)
        samplesBtn.setImage(UIImage(named: "unselected"), for: .normal)
        sampleLabBtn.setImage(UIImage(named: "unselected"), for: .normal)
    }
    
    @IBAction func orderUploadedBtnAction(_ sender: UIButton) {
        radioController.buttonArrayUpdated(buttonSelected: sender)
        statusId = "8"
        print(statusId ?? "")
        orderUploadedBtn.setImage(UIImage(named: "selected"), for: .normal)
        NotAvailableBtn.setImage(UIImage(named: "unselected"), for: .normal)
        cancelledBtn.setImage(UIImage(named: "unselected"), for: .normal)
        labGenerateBtn.setImage(UIImage(named: "unselected"), for: .normal)
        btAssignedBtn.setImage(UIImage(named: "unselected"), for: .normal)
        samplesBtn.setImage(UIImage(named: "unselected"), for: .normal)
        sampleLabBtn.setImage(UIImage(named: "unselected"), for: .normal)
    }
    
    
    @IBAction func btAssignedButtonAction(_ sender: UIButton) {
        radioController.buttonArrayUpdated(buttonSelected: sender)
        statusId = "10"
        print(statusId ?? "")
        btAssignedBtn.setImage(UIImage(named: "selected"), for: .normal)
        NotAvailableBtn.setImage(UIImage(named: "unselected"), for: .normal)
        cancelledBtn.setImage(UIImage(named: "unselected"), for: .normal)
        orderUploadedBtn.setImage(UIImage(named: "unselected"), for: .normal)
        labGenerateBtn.setImage(UIImage(named: "unselected"), for: .normal)
        samplesBtn.setImage(UIImage(named: "unselected"), for: .normal)
        sampleLabBtn.setImage(UIImage(named: "unselected"), for: .normal)
    }
    
    @IBAction func samplesBtnAction(_ sender: UIButton) {
        radioController.buttonArrayUpdated(buttonSelected: sender)
        statusId = "11"
        print(statusId ?? "")
        samplesBtn.setImage(UIImage(named: "selected"), for: .normal)
        NotAvailableBtn.setImage(UIImage(named: "unselected"), for: .normal)
        cancelledBtn.setImage(UIImage(named: "unselected"), for: .normal)
        orderUploadedBtn.setImage(UIImage(named: "unselected"), for: .normal)
        btAssignedBtn.setImage(UIImage(named: "unselected"), for: .normal)
        labGenerateBtn.setImage(UIImage(named: "unselected"), for: .normal)
        sampleLabBtn.setImage(UIImage(named: "unselected"), for: .normal)
    }
    
    
    @IBAction func samplesLabBtnAction(_ sender: UIButton) {
        radioController.buttonArrayUpdated(buttonSelected: sender)
        statusId = "12"
        print(statusId ?? "")
        sampleLabBtn.setImage(UIImage(named: "selected"), for: .normal)
        NotAvailableBtn.setImage(UIImage(named: "unselected"), for: .normal)
        cancelledBtn.setImage(UIImage(named: "unselected"), for: .normal)
        orderUploadedBtn.setImage(UIImage(named: "unselected"), for: .normal)
        btAssignedBtn.setImage(UIImage(named: "unselected"), for: .normal)
        samplesBtn.setImage(UIImage(named: "unselected"), for: .normal)
        labGenerateBtn.setImage(UIImage(named: "unselected"), for: .normal)
    }
    
    
  //  func filterContentForSearchText(_ searchText: String) {
           // filteredOrderedArray = ordersArray.filter({( product : OrderList) -> Bool in
              //  return product.phoneNumber.lowercased().contains(searchText.lowercased())
           // })
           // ordersTableView.reloadData() // reload your table view
   // }

    
    @IBAction func cancelBtnViewAction(_ sender: Any) {
        orderStatusView.isHidden = true
        blankImageview.isHidden = true
    }
    
    @IBAction func okButtonAction(_ sender: Any) {
        
        if statusId != nil {
        let alertController = UIAlertController(title: "Lab Technician", message: "Are you sure you want to update the status?", preferredStyle: .alert)
        let ok = UIAlertAction(title: "Ok", style: .default, handler: { [self] action in
            serviceForUpdateStatus(btnString: "status")
        })
        let cancel = UIAlertAction(title: "Cancel", style: .default, handler: nil)
            alertController.addAction(ok)
            alertController.addAction(cancel)
            present(alertController, animated: true)
        }
        else{
            let alertController = UIAlertController(title: "Lab Technician", message: "Please Choose Any One Option from the Above List", preferredStyle: .alert)
            let ok = UIAlertAction(title: "Ok", style: .default, handler: nil)
            alertController.addAction(ok)
            present(alertController, animated: true)
        }
    }
    
    //MARK: - APIS
    func serviceForUpdateStatus(btnString:String?) {
        NetWorkMonitor.shared.monitor { status in
            if (status == true)
            {
                let url =  APIConstants.uploadImage
                //let labID = UserDefaults.standard.string(forKey: "labID") ?? ""
               // let id = UserDefaults.standard.string(forKey: "id") ?? ""
                if btnString == "image"{
                    self.jsonDictionary = ["DocumentName": self.pickerImgString ?? "","DocumentPath": self.base64String ?? "","FilledStatusId": "10","LabTestID": "1","PatientID": self.passId ?? "","LabOrderID": self.labID ?? ""]
                
                APIHandler.shared.POSTServiceWithParameters(path: url, postString: self.jsonDictionary) { result, error in
                    let response = result
                    DispatchQueue.main.async {
                    if response as! Int == 1 {
                            self.view.addSubview(self.activityIndicator)
                            self.ordersTableView.reloadData()
                            let alertController = UIAlertController(title: "Lab Technician", message: "Image Uploaded successfully", preferredStyle: .alert)
                            let ok = UIAlertAction(title: "OK", style: .default, handler: { [self] action in
                            let orders = storyboard?.instantiateViewController(withIdentifier: "OrdersViewController") as! OrdersViewController
                            orders.modalPresentationStyle = UIModalPresentationStyle.fullScreen
                            self.present(orders, animated: true, completion: nil)
                           // self.serviceForGetOrders()
                            })
                            alertController.addAction(ok)
                            self.present(alertController, animated: true)
                            self.activityIndicator.hide()
                        }
                        else{
                            self.view.addSubview(self.activityIndicator)
                            let alertController = UIAlertController(title: "Lab Technician", message: "Failed In Uploading Image", preferredStyle: .alert)
                            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                            alertController.addAction(ok)
                            self.present(alertController, animated: true)
                            self.activityIndicator.hide()
                        }
                        self.orderStatusView.isHidden = true
                        self.blankImageview.isHidden = true
                        self.ordersTableView.reloadData()
                    }
            }
            }
                else{
                        self.jsonDictionary = ["DocumentName": "","DocumentPath": "","FilledStatusId": self.statusId ?? "","LabTestID": "2","PatientID":self.passId ?? "", "LabOrderID": self.labID ?? ""]
                        
                        APIHandler.shared.POSTServiceWithParameters(path: url, postString: self.jsonDictionary) { result, error in
                            let response = result
                            DispatchQueue.main.async {
                            if response as! Int == 1 {
                                self.ordersTableView.reloadData()
                                self.view.addSubview(self.activityIndicator)
                                let alertController = UIAlertController(title: "Lab Technician", message: "Status Updated successfully", preferredStyle: .alert)
                                let ok = UIAlertAction(title: "OK", style: .default, handler: { [self] action in
                                let orders = storyboard?.instantiateViewController(withIdentifier: "OrdersViewController") as! OrdersViewController
                                orders.modalPresentationStyle = UIModalPresentationStyle.fullScreen
                                self.present(orders, animated: true, completion: nil)
                                self.activityIndicator.hide()
                                self.orderStatusView.isHidden = true
                                self.blankImageview.isHidden = true
                                self.ordersTableView.reloadData()
                                self.statusId = "0"
                                })
                                alertController.addAction(ok)
                                self.present(alertController, animated: true)
                                }
                                else{
                                    self.view.addSubview(self.activityIndicator)
                                    let alertController = UIAlertController(title: "Lab Technician", message: "Status Not updated", preferredStyle: .alert)
                                    let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                                    alertController.addAction(ok)
                                    self.present(alertController, animated: true)
                                    self.activityIndicator.hide()
                                }
                            }
                    }
                    }

                    }
            else
            {
                DispatchQueue.main.async {
                    self.view.addSubview(self.activityIndicator)
                    let alertController = UIAlertController(title: "Lab Technician", message: "Connection Error", preferredStyle: .alert)
                    let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alertController.addAction(ok)
                    self.present(alertController, animated: true)
                    self.activityIndicator.hide()
                }
            }
        }
    }
    
    
    func serviceForGetOrders() {
        NetWorkMonitor.shared.monitor { status in
            if (status == true)
            {
                let url =  APIConstants.orderList
                let labID = UserDefaults.standard.string(forKey: "labID") ?? ""
                let ltID = UserDefaults.standard.string(forKey: "userID") ?? ""
                self.jsonDictionary = ["CreatedOn": "","LabID": labID,"UpdatedOn": "","ltID": ltID,"phonenumber": "","uid": ""]
                APIHandler.shared.POSTService(path: url, postString: self.jsonDictionary, responseType: [OrderList].self) { result, error in
                
                    self.ordersArray = result as! [OrderList]
                  
                    DispatchQueue.main.async {
                    if self.ordersArray.count > 0 {
                        self.view.addSubview(self.activityIndicator)
                        self.ordersTableView.reloadData()
                        self.activityIndicator.hide()
                    }
                        else{
                            self.view.addSubview(self.activityIndicator)
                            let alertController = UIAlertController(title: "Lab Technician", message: "No records available currently", preferredStyle: .alert)
                            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                            alertController.addAction(ok)
                            self.present(alertController, animated: true)
                            self.activityIndicator.hide()
                        }
                    }
                }
            }
            else
            {
                DispatchQueue.main.async {
                    self.view.addSubview(self.activityIndicator)
                    let alertController = UIAlertController(title: "Lab Technician", message: "Connection Error", preferredStyle: .alert)
                    let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alertController.addAction(ok)
                    self.present(alertController, animated: true)
                    self.activityIndicator.hide()
                }
            }
        }
    }
   
}

//MARK: - UIImagePickerControllerDelegate

extension OrdersViewController:  UIImagePickerControllerDelegate, UINavigationControllerDelegate{

      func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
          if picker.sourceType == .photoLibrary {
              if let pickedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage {
                  let imageData: Data? = pickedImage.jpegData(compressionQuality: 0.5)
                  guard let fileUrl = info[UIImagePickerController.InfoKey.imageURL] as? URL else { return }
                     // print(fileUrl.lastPathComponent)
                  pickerImgString = fileUrl.lastPathComponent
                  let imageStr = imageData?.base64EncodedString(options: .lineLength64Characters) ?? ""
                    //print(imageStr)
                  base64String = imageStr
                       }
          }
          else {
              var imageUrl: URL!
              if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
                  let imgName = "\(UUID().uuidString).jpeg"
                  let documentDirectory = NSTemporaryDirectory()
                  let localPath = documentDirectory.appending(imgName)
                  let imageData: NSData? = pickedImage.jpegData(compressionQuality: 0.5) as NSData?
                  imageData!.write(toFile: localPath, atomically: true)
                  imageUrl = URL.init(fileURLWithPath: localPath)
                  //print(imageUrl.lastPathComponent)
                  pickerImgString = imageUrl.lastPathComponent
                  let imageStr = imageData?.base64EncodedString(options: .lineLength64Characters) ?? ""
                  //print(imageStr)
                  base64String = imageStr
                }
          }
          self.view.addSubview(self.activityIndicator)
          let orders = storyboard?.instantiateViewController(withIdentifier: "OrdersViewController") as! OrdersViewController
          orders.modalPresentationStyle = UIModalPresentationStyle.fullScreen
          self.present(orders, animated: true, completion: nil)
          serviceForUpdateStatus(btnString: "image")
          picker.dismiss(animated: true, completion: nil)
          self.activityIndicator.hide()
     }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.isNavigationBarHidden = false
        self.dismiss(animated: true, completion: nil)
    }
}



extension String {

     func isNilOrEmpty(string: String?) -> Bool {
        guard let value = string else { return true }

        return value.trimmingCharacters(in: .whitespaces).isEmpty
    }
    
    
}


extension String {
    func dateChanges(str:String){
     var dateValue: Date? {
       let dateAsString = str
       let dateFormatter = DateFormatter()
       dateFormatter.dateFormat = str
       let date = dateFormatter.date(from: dateAsString) //date is being nil here
       let Date24 = dateFormatter.string(from: date!)
       print("24 hour formatted Date:",Date24)
       return date
      }
   }
}
