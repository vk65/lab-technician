//
//  HomeViewController.swift
//  Lab techinans
//
//  Created by Sambav on 23/06/22.
//

import UIKit

class HomeViewController: UIViewController, UIViewControllerTransitioningDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    //MARK: - UIButton
    @IBAction func menuButtonAction(_ sender: Any) {
        let menuViewController = storyboard?.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        menuViewController.modalPresentationStyle = UIModalPresentationStyle.custom
        menuViewController.transitioningDelegate = self
        menuViewController.view.backgroundColor = .clear
        let transition = CATransition()
        transition.duration = 0.3
        transition.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        transition.type = CATransitionType.push
        transition.subtype = CATransitionSubtype.fromLeft
        view.window!.layer.add(transition, forKey: nil)
        present(menuViewController, animated: false)
    }
    
}
