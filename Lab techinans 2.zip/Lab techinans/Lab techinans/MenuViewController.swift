//
//  MenuViewController.swift
//  Lab techinans
//
//  Created by Sambav on 20/06/22.
//

import UIKit

class MenuViewController: UIViewController, UIPickerViewDelegate, UIViewControllerTransitioningDelegate, UITableViewDelegate, UITableViewDataSource  {
    let cellReuseIdentifier = "MenuTableViewCell"
    let orderController: OrdersViewController = OrdersViewController()
    var imagePicker = UIImagePickerController()
    @IBOutlet weak var profileName: UILabel!
    @IBOutlet weak var profileImg: UIImageView!
    @IBOutlet weak var menuTableview: UITableView!
    var menuArray = ["Assigned Lab Orders", "Change Password", "Logout"]
    let activityIndicator = ActivityIndicator()
    // var imagePicker: ImagePicker?
    //MARK: - ViewLifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        profileImg.layer.cornerRadius = 10.0
        profileImg.layer.borderWidth = 0.5
        profileImg.layer.masksToBounds = false
        profileImg.layer.borderColor = UIColor.white.cgColor
        profileImg.layer.cornerRadius = 13
        profileImg.layer.cornerRadius = profileImg.frame.size.height / 2
        profileImg.clipsToBounds = true
        profileName.text = UserDefaults.standard.string(forKey: "fullName")
        menuTableview.backgroundColor = UIColor.clear
        serviceForGetProfilePicture()
        // Do any additional setup after loading the view.
    }
    
    
    //MARK: - TABLEVIEW DELEGATE METHODS
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // set the text from the data model
        let cell = tableView.dequeueReusableCell(withIdentifier: cellReuseIdentifier, for: indexPath) as! MenuTableViewCell
        
        //for table view border
        menuTableview.separatorStyle = .none
        menuTableview.separatorColor = .clear
        cell.backgroundColor = .clear
        cell.contentView.layer.cornerRadius = 6
        cell.contentView.layer.masksToBounds = true
       // cell.contentView.backgroundColor = .clear
        if (indexPath.row == 0){
            if UserDefaults.standard.string(forKey: "Assigned Lab Orders") == "MenuButtonSelected" {
                cell.menubackgroundImg.backgroundColor = UIColor(red: 0.82, green: 0.43, blue: 0.05, alpha: 1.00)
            }
            else {
                cell.menubackgroundImg.backgroundColor = .clear
            }
           cell.menubackgroundImg.backgroundColor = UIColor(red: 0.82, green: 0.43, blue: 0.05, alpha: 1.00)
            cell.assignedLabOrderBtn.setTitle("Assigned Lab Orders", for: .normal)
            cell.labIconImg.image = UIImage(named: "lab-w")
            cell.assignedLabOrderBtn.addTarget(self, action: #selector(labOrders), for: .touchUpInside)
        }
        else if (indexPath.row == 1){
            if UserDefaults.standard.string(forKey: "Change Password") == "MenuButtonSelected" {
                cell.menubackgroundImg.backgroundColor = UIColor(red: 0.82, green: 0.43, blue: 0.05, alpha: 1.00)
            }
            else {
                cell.menubackgroundImg.backgroundColor = .clear
            }
           // cell.menubackgroundImg.backgroundColor = UIColor(red: 0.82, green: 0.43, blue: 0.05, alpha: 1.00)
            cell.assignedLabOrderBtn.setTitle("Change Password", for: .normal)
            cell.labIconImg.image = UIImage(named: "key background")
            cell.assignedLabOrderBtn.addTarget(self, action: #selector(passwordChangeAction), for: .touchUpInside)
        }
        else {
            if UserDefaults.standard.string(forKey: "Logout") == "MenuButtonSelected" {
                cell.menubackgroundImg.backgroundColor = UIColor(red: 0.82, green: 0.43, blue: 0.05, alpha: 1.00)
            }
            else {
                cell.menubackgroundImg.backgroundColor = .clear
            }
           // cell.menubackgroundImg.backgroundColor = UIColor(red: 0.82, green: 0.43, blue: 0.05, alpha: 1.00)
            cell.assignedLabOrderBtn.setTitle("Logout", for: .normal)
            cell.labIconImg.image = UIImage(named: "logout")
            cell.assignedLabOrderBtn.addTarget(self, action: #selector(logoutBtnAction), for: .touchUpInside)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath) as? MenuTableViewCell
        if (indexPath.row == 0){
            cell!.menubackgroundImg.backgroundColor = UIColor(red: 0.82, green: 0.43, blue: 0.05, alpha: 1.00)
            let homeVC = self.storyboard?.instantiateViewController(withIdentifier: "OrdersViewController") as! OrdersViewController
            homeVC.modalPresentationStyle = .fullScreen
            //navigationController?.pushViewController(homeVC, animated: true)
            self.present(homeVC, animated: true, completion: nil)
        }
        
        else if (indexPath.row == 1)
        {
            cell!.menubackgroundImg.backgroundColor = UIColor(red: 0.82, green: 0.43, blue: 0.05, alpha: 1.00)
            let homeVC = self.storyboard?.instantiateViewController(withIdentifier: "ChangePasswordViewController") as! ChangePasswordViewController
            homeVC.modalPresentationStyle = .fullScreen
            //navigationController?.pushViewController(homeVC, animated: true)
            self.present(homeVC, animated: true, completion: nil)
        }
        
        else {
            cell!.menubackgroundImg.backgroundColor = UIColor(red: 0.82, green: 0.43, blue: 0.05, alpha: 1.00)
            let alertController = UIAlertController(title: "Lab Technician", message: "Are you sure you want to logout?", preferredStyle: .alert)
            let cancel = UIAlertAction(title: "Cancel", style: .default, handler: nil)
            alertController.addAction(cancel)
            let ok = UIAlertAction(title: "Ok", style: .default, handler: { [self] action in
                let viewController = storyboard!.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
                viewController.modalPresentationStyle = UIModalPresentationStyle.fullScreen
                    present(viewController, animated: false)
            })
                alertController.addAction(ok)
                present(alertController, animated: true)
        }
    }

    //MARK: - UIButton
    @IBAction func menuCancelButtonAction(_ sender: Any) {
        let transition = CATransition()
        transition.duration = 0.3
        transition.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        transition.type = .push
        transition.subtype = .fromRight
        view.window!.layer.add(transition, forKey: nil)
        dismiss(animated: false)
    }
    
    @objc func labOrders(){
        UserDefaults.standard.set("Assigned Lab Orders", forKey: "MenuButtonSelected")
        UserDefaults.standard.synchronize()
        let homeVC = self.storyboard?.instantiateViewController(withIdentifier: "OrdersViewController") as! OrdersViewController
        homeVC.modalPresentationStyle = .fullScreen
        //navigationController?.pushViewController(homeVC, animated: true)
        self.present(homeVC, animated: true, completion: nil)
    }
    
    @objc func passwordChangeAction(){
        UserDefaults.standard.set("Change Password", forKey: "MenuButtonSelected")
        UserDefaults.standard.synchronize()
        let homeVC = self.storyboard?.instantiateViewController(withIdentifier: "ChangePasswordViewController") as! ChangePasswordViewController
        homeVC.modalPresentationStyle = .fullScreen
        //navigationController?.pushViewController(homeVC, animated: true)
        self.present(homeVC, animated: true, completion: nil)
    }
    
    @objc func logoutBtnAction(){
        UserDefaults.standard.set("Logout", forKey: "MenuButtonSelected")
        UserDefaults.standard.synchronize()
        let alertController = UIAlertController(title: "Lab Technician", message: "Are you sure you want to logout?", preferredStyle: .alert)
        let cancel = UIAlertAction(title: "Cancel", style: .default, handler: nil)
        alertController.addAction(cancel)
        let ok = UIAlertAction(title: "Ok", style: .default, handler: { [self] action in
            let viewController = storyboard!.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
            viewController.modalPresentationStyle = UIModalPresentationStyle.fullScreen
                present(viewController, animated: false)
        })
            alertController.addAction(ok)
            present(alertController, animated: true)
    }
    
    
    @IBAction func addImageAction(_ sender: UIButton) {
        let alert = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Take Photo", style: .default, handler: { _ in
            self.openCamera()
        }))
        
        alert.addAction(UIAlertAction(title: "Choose Photo", style: .default, handler: { _ in
            self.openGallary()
        }))
        
        alert.addAction(UIAlertAction.init(title: "Cancel", style: .cancel, handler: nil))
        
        //If you want work actionsheet on ipad then you have to use popoverPresentationController to present the actionsheet, otherwise app will crash in iPad
        switch UIDevice.current.userInterfaceIdiom {
        case .pad:
            alert.popoverPresentationController?.sourceView = sender
            alert.popoverPresentationController?.sourceRect = sender.bounds
            alert.popoverPresentationController?.permittedArrowDirections = .up
        default:
            break
        }
        
        self.present(alert, animated: true, completion: nil)

    }
    
    //MARK: - Open the camera
    func openCamera(){
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerController.SourceType.camera)){
            imagePicker.sourceType = UIImagePickerController.SourceType.camera
            //If you dont want to edit the photo then you can set allowsEditing to false
            imagePicker.allowsEditing = true
            imagePicker.delegate = self
            self.present(imagePicker, animated: true, completion:nil)
        }
        else{
            let alert  = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    //MARK: - Choose image from camera roll
   func openGallary(){
        imagePicker.sourceType = UIImagePickerController.SourceType.photoLibrary
        //If you dont want to edit the photo then you can set allowsEditing to false
        imagePicker.allowsEditing = true
        imagePicker.delegate = self
        self.present(imagePicker, animated: true, completion: nil)
    }
    
    
    //MARK: - APIS
    //MARK: - APIS
    func serviceForGetProfilePicture() {
       // MBProgressHUD.showAdded(to: self.view, animated: true)
        NetWorkMonitor.shared.monitor { status in
            if status == true{
                let uid = UserDefaults.standard.string(forKey: "userID") ?? ""
                let url =  APIConstants.getProficPic + "userId=\(uid)&userTypeId=4"
                APIHandler.shared.POSTService(path: url, postString: [:], responseType: ProfilePicture.self) { result, error in
                    let response = result as? ProfilePicture
                    DispatchQueue.main.async {
                        //MBProgressHUD.hide(for: self.view, animated: true)
                    if let object = response?.imagePath {
                            self.profileImg.imageFromUrl(urlString: object)
                        }
                    }
                }
            }
            else
            {
                DispatchQueue.main.async {
                  //  MBProgressHUD.hide(for: self.view, animated: true)
                    let alertController = UIAlertController(title: "Lab Technician", message: "Connection Error", preferredStyle: .alert)
                    let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alertController.addAction(ok)
                    self.present(alertController, animated: true)
                }
            }
        }
    }
}

extension MenuViewController:  UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
       if let pickedImage = info[.originalImage] as? UIImage {
           profileImg.image = pickedImage
       }
       picker.dismiss(animated: true, completion: nil)
   }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.isNavigationBarHidden = false
        self.dismiss(animated: true, completion: nil)
    }
}

extension UIImageView {
    public func imageFromUrl(urlString: String) {
        if let url = NSURL(string: urlString) {
            let request = NSURLRequest(url: url as URL)
            NSURLConnection.sendAsynchronousRequest(request as URLRequest, queue: OperationQueue.main) {
                (response: URLResponse?, data: Data?, error: Error?) -> Void in
                if let imageData = data as Data? {
                    self.image = UIImage(data: imageData)
                }
            }
        }
    }
}

