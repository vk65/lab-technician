//
//  OrdersTableViewCell.swift
//  Lab techinans
//
//  Created by Sambav on 24/06/22.
//

import UIKit

class OrdersTableViewCell: UITableViewCell {

    @IBOutlet weak var paymentLabel: UILabel!
    
    @IBOutlet weak var orderTypeLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var orderDateLbl: UILabel!
    
    @IBOutlet weak var viewSampleBtn: UIButton!
    @IBOutlet weak var labOrderStatusLbl: UILabel!
    @IBOutlet weak var uploadStatusBtn: UIButton!
    @IBOutlet weak var uploadBtn: UIButton!
    @IBOutlet weak var mobileLabel: UILabel!
    @IBOutlet weak var uidLabel: UILabel!
    @IBOutlet weak var packageLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
  
}
