//
//  ChangePasswordViewController.swift
//  Lab techinans
//
//  Created by Sambav on 23/06/22.
//

import UIKit

class ChangePasswordViewController: UIViewController, UITextFieldDelegate {
    var passwordShowOrHide, confirmpasswordShowOrHide: Bool!
    @IBOutlet weak var newPasswordTextField: UITextField!
    var jsonData = [String:Any]()
    @IBOutlet weak var confirmTextField: UITextField!
    let activityIndicator = ActivityIndicator()
    //MARK: - View Controller Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        newPasswordTextField.delegate = self
        confirmTextField.delegate = self
        self.hideKeyboardOnTapAround()
        // Do any additional setup after loading the view.
    }
    
    override func viewDidLayoutSubviews() {
        newPasswordTextField.addBottomBorder()
        confirmTextField.addBottomBorder()
    }
    
    //MARK:- Valid Password address
    func isValidPassword(password:String) -> Bool {
        let passwordRegex = "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z!@#$%^&*()\\-_=+{}|?>.<,:;~`’]{8,}$"
        let result = NSPredicate(format: "SELF MATCHES %@", passwordRegex).evaluate(with: password)
        return result
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            self.view.endEditing(true)
            return false
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == newPasswordTextField {
            textField.addBlueColor()
        }
        else if textField == confirmTextField {
            textField.addBlueColor()
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == newPasswordTextField {
            textField.addBottomBorder()
        }
        else if textField == confirmTextField {
            textField.addBottomBorder()
        }

    }
    func hideKeyboardOnTapAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.hideKeyboard))
        tap.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tap)
    }

    @objc func hideKeyboard() {
        self.view.endEditing(true)
    }
        

    
    //MARK: - UIButton
    @IBAction func newPasswordHideAction(_ sender: Any) {
        if (confirmpasswordShowOrHide == true) {
            newPasswordTextField.isSecureTextEntry = true
            confirmpasswordShowOrHide = false
        } else {
            confirmpasswordShowOrHide = true
            newPasswordTextField.isSecureTextEntry = false
        }
    }
    
    
    @IBAction func backButtonAction(_ sender: Any) {
        let back = self.storyboard!.instantiateViewController(withIdentifier: "OrdersViewController") as! OrdersViewController
        back.modalPresentationStyle = UIModalPresentationStyle.fullScreen
        self.present(back, animated: false)
    }
    
    @IBAction func cinfirmPasswordHideAction(_ sender: Any) {
        if (confirmpasswordShowOrHide == true) {
            confirmTextField.isSecureTextEntry = true
            confirmpasswordShowOrHide = false
        } else {
            confirmpasswordShowOrHide = true
            confirmTextField.isSecureTextEntry = false
        }
    }
    
    @IBAction func submitButtonAction(_ sender: Any) {
        if isValidPassword(password: newPasswordTextField.text!) == false {
            let alertController = UIAlertController(title: "Lab Technician", message: "Password must have minimum one number, one uppercase, one special character (! @ # $). Password should contain at least 8 characters.", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(ok)
            present(alertController, animated: true, completion: nil)
        }
        else if confirmTextField.text == "" {
            let alertController = UIAlertController(title: "Lab Technician", message: "Enter Confirm Password", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(ok)
            present(alertController, animated: true)
        }
        else if newPasswordTextField.text != confirmTextField.text {
            let alertController = UIAlertController(title: "Lab Technician", message: "Passwords are not match", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(ok)
            present(alertController, animated: true)
        }
        else
        {
            let passwordString = self.newPasswordTextField.text ?? ""
            let oldPasswordString = self.confirmTextField.text ?? ""
            view.endEditing(true)
             NetWorkMonitor.shared.monitor { (status) -> (Void) in
            if status == true {
                let urlString = APIConstants.changePassword
                 //let object = UserDefaults.standard.string(forKey: "userID") //let object1 = UserDefaults.standard.string(forKey: "id") {
                    let labID = UserDefaults.standard.string(forKey: "labID") ?? ""
                    let userID = UserDefaults.standard.string(forKey: "userID") ?? ""
                    let userName = UserDefaults.standard.string(forKey: "userName") ?? ""
                    self.jsonData = ["ID": userID,"LabID": labID,"SetP": true,"Type": 1,"UpdatedDate": "","UserName": userName ,"password": passwordString]
                APIHandler.shared.POSTService(path: urlString, postString: self.jsonData, responseType: ChangeDetails.self) { result, error in
                    let changedResponse = result as! ChangeDetails
                    if  changedResponse.code == 1 {
                        DispatchQueue.main.async {
                        let alertController = UIAlertController(title: "Lab Technician", message: "Password Updated Successfully", preferredStyle: .alert)
                        let ok = UIAlertAction(title: "OK", style: .default, handler: { action in
                            let login = self.storyboard!.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
                            login.modalPresentationStyle = UIModalPresentationStyle.fullScreen
                            self.present(login, animated: false)
                                })
                        alertController.addAction(ok)
                        self.present(alertController, animated: true)
                     }
                    }
                }
             }
            else
            {
                DispatchQueue.main.async {
                    //finally hide it, whether its sucess or failure just remove it
                    let alertController = UIAlertController(title: "Lab Technician", message: "Connection Error", preferredStyle: .alert)
                    let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alertController.addAction(ok)
                    self.present(alertController, animated: true, completion: nil)
            }
        }
        }
    }
    }
    
    
    @IBAction func keyboardDismissBtnAction(_ sender: Any) {
        view.endEditing(true)
    }
    
    
    @IBAction func cancelBtnAction(_ sender: Any) {
        let homeVC = self.storyboard?.instantiateViewController(withIdentifier: "OrdersViewController") as! OrdersViewController
        homeVC.modalPresentationStyle = .fullScreen
        //navigationController?.pushViewController(homeVC, animated: true)
        self.present(homeVC, animated: true, completion: nil)
    }
    
}
