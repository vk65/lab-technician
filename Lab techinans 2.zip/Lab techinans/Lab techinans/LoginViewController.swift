//
//  ViewController.swift
//  Lab techinans
//
//  Created by Sambav on 20/06/22.
//

import UIKit

class LoginViewController: UIViewController, UITextFieldDelegate {
    var latitudeString: String?
    var longitudeString: String?
    var jsonObjects = [serviceForGetTime]()
    var passwordShowOrHide, confirmpasswordShowOrHide, forgotPasswordBoolValue: Bool!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    let activityIndicator = ActivityIndicator()
    //MARK: - View Controller Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        emailTextField.delegate = self
        passwordTextField.delegate = self
        self.hideKeyboardOnTapAround()
        // Do any additional setup after loading the view.
    }
    
    override func viewDidLayoutSubviews() {
        emailTextField.addBottomBorder()
        passwordTextField.addBottomBorder()
    }


    
    //MARK: - KEYBOARD-DISMISS METHOD
    func hideKeyboardOnTapAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.hideKeyboard))
        tap.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tap)
    }

    @objc func hideKeyboard() {
        self.view.endEditing(true)
    }
    
    //MARK: - TEXTFIELD DELEGATE METHODS
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == emailTextField {
            textField.addBlueColor()
        }
        else if textField == passwordTextField {
            textField.addBlueColor()
        }
    }

    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == emailTextField {
            textField.addBottomBorder()
        }
        else if textField == passwordTextField {
            textField.addBottomBorder()
        }

    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
           self.view.endEditing(true)
           return false
       }

    func makeUnderline(for textField: UITextField) {
        let bottomBorder = CALayer()
        bottomBorder.frame = CGRect(x: 0, y: textField.frame.size.height - 1, width: textField.frame.size.width, height: 1)
        bottomBorder.backgroundColor = UIColor.darkGray.cgColor
        textField.layer.addSublayer(bottomBorder)
    }
 
    //MARK: - UIBUTTON METHODS
    @IBAction func forgotButtonAction(_ sender: Any) {
        let forgotVC = self.storyboard?.instantiateViewController(withIdentifier: "ForgotPasswordViewController") as! ForgotPasswordViewController
        forgotVC.modalPresentationStyle = .fullScreen
        //navigationController?.pushViewController(homeVC, animated: true)
        self.present(forgotVC, animated: true, completion: nil)
    }
    
    
    @IBAction func touchBeganBtnAction(_ sender: Any) {
        view.endEditing(true)
    }
    
    
    @IBAction func passwordHideBtnAction(_ sender: Any) {
        if (confirmpasswordShowOrHide == true) {
            passwordTextField.isSecureTextEntry = true
            confirmpasswordShowOrHide = false
        } else {
            confirmpasswordShowOrHide = true
            passwordTextField.isSecureTextEntry = false
        }
    }
    
    @IBAction func loginButtonAction(_ sender: Any) {
        if (emailTextField.text == "") && (passwordTextField.text == "") {
            let alertController = UIAlertController(title: "Lab Technician", message: "Enter Email or Mobile Number and Password", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(ok)
            present(alertController, animated: true, completion: nil)
        }
        else if emailTextField.text == "" {
            let alertController = UIAlertController(title: "Lab Technician", message: "Enter Email or Mobile Number", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(ok)
            present(alertController, animated: true)
        }
        else if passwordTextField.text == "" {
            let alertController = UIAlertController(title: "Lab Technician", message: "Enter Password", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(ok)
            present(alertController, animated: true)
        }
        else {
            NetWorkMonitor.shared.monitor { status in
                
                if status == true{
                    let url:String = APIConstants.loginPath
                    print(url)
                    DispatchQueue.main.async {
                        let postData = ["UserTypeID" : "22","IsOtpValid" : "true","UserName" : self.emailTextField.text!,
                                        "Password" : self.passwordTextField.text!] as [String : Any]
                    APIHandler.shared.POSTService(path: url, postString: postData, responseType: LoginResponse.self) {  result, error in
                        if let loginResponse = result as? LoginResponse{
                            if error != nil{
                                if loginResponse.expires == "expired" {
                                    DispatchQueue.main.async {
                                        let alertController = UIAlertController(title: "Lab Technician", message: "Your subscription has been expired. Please pay to continue caring and access to better healthcare.", preferredStyle: .alert)
                                        let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                                        self.present(alertController, animated: true)
                                        {
                                            UserDefaults.standard.set(LoginFailureType.error_description, forKey: "userID")
                                            UserDefaults.standard.synchronize()
                                            UserDefaults.standard.set(LoginFailureType.error_uri, forKey: "userCountry")
                                            UserDefaults.standard.synchronize()
                                            UserDefaults.standard.set(LoginFailureType.Expired, forKey: "PaymentStatus")
                                            UserDefaults.standard.synchronize()
                                            UserDefaults.standard.set("", forKey: "userToken")
                                            UserDefaults.standard.synchronize()
                                            alertController.addAction(ok)
                                            self.present(alertController, animated: true)
                                        }
                                    }
                                }
                                else
                                {
                                    DispatchQueue.main.async {
                                        let alertController = UIAlertController(title: "Lab Technician", message: LoginFailureType.error_description as? String, preferredStyle: .alert)
                                        let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                                        alertController.addAction(ok)
                                        self.present(alertController, animated: true)
                                    }
                                }
                                
                            }else
                            {
                                UserDefaults.standard.set(loginResponse.userName, forKey: "userName")
                                UserDefaults.standard.synchronize()
                                UserDefaults.standard.set(loginResponse.fullName, forKey: "fullName")
                                UserDefaults.standard.synchronize()
                                UserDefaults.standard.set(loginResponse.userID, forKey: "userID")
                                UserDefaults.standard.synchronize()
                                UserDefaults.standard.set(loginResponse.cc, forKey: "userCountry")
                                UserDefaults.standard.set(loginResponse.userName, forKey: "UID")
                                UserDefaults.standard.set(loginResponse.orgID, forKey: "labID")
                               // UserDefaults.standard.set(loginResponse.userID, forKey: "ltid")
                                UserDefaults.standard.set(loginResponse.userName, forKey: "userName")
                                UserDefaults.standard.synchronize()
                                if let object = loginResponse.accessToken{
                                    UserDefaults.standard.set("Bearer \(object)", forKey: "userToken")
                                }
                                UserDefaults.standard.set("Yes", forKey: "isFirstTime")
                                UserDefaults.standard.synchronize()

                                DispatchQueue.main.async {
                                    if loginResponse.userID?.count ?? 0 > 0{
                                        self.view.addSubview(self.activityIndicator)
                                        let homeVC = self.storyboard?.instantiateViewController(withIdentifier: "OrdersViewController") as! OrdersViewController
                                        homeVC.modalPresentationStyle = .fullScreen
                                        //navigationController?.pushViewController(homeVC, animated: true)
                                        self.present(homeVC, animated: true, completion: nil)
                                        self.activityIndicator.hide()
                                    }
                                    else
                                    {
                                        self.view.addSubview(self.activityIndicator)
                                        let alertController = UIAlertController(title: "Lab Technician", message: "Invalid Username/Password", preferredStyle: .alert)
                                        let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                                        alertController.addAction(ok)
                                        self.present(alertController, animated: true, completion: nil)
                                        self.activityIndicator.hide()
                                    }
                                }
                            }
                        }
                    }
                    
                }
            }else
            {
                DispatchQueue.main.async{
                    //finally hide it, whether its sucess or failure just remove it
                    let alertController = UIAlertController(title: "Lab Technician", message: "Connection Error", preferredStyle: .alert)
                    let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alertController.addAction(ok)
                    self.present(alertController, animated: true, completion: nil)
                }
            }
        }
    }

            }
    
    // MARK: - Location API Services
    func serviceForGetTimeStamp() {
        NetWorkMonitor.shared.monitor { (success) -> (Void) in
            if success == true {
                // Create the URLSession on the default configuration
                let url = APIConstants.baseUrl + "api/common/GetTimeStamp?latlon=\(self.latitudeString!),\(self.longitudeString!)"
                APIHandler.shared.GETService(path: url, responeType: serviceForGetTime.self) {[self] result, error in
                    if result != nil {
                    jsonObjects = result as! [serviceForGetTime]
                    for i in 0..<jsonObjects.count{
                        if jsonObjects[i].isError != nil {
                            if let object = jsonObjects[i].isError {
                                if "\(object)" == "0" {
                                    UserDefaults.standard.set("false", forKey: "IsError")
                                    UserDefaults.standard.synchronize()
                                } else {
                                    UserDefaults.standard.set("true", forKey: "IsError")
                                    UserDefaults.standard.synchronize()
                                }
                                UserDefaults.standard.set(jsonObjects[i].timestamp, forKey: "TimeStamp")
                                UserDefaults.standard.synchronize()
                                UserDefaults.standard.set("\(latitudeString!),\(longitudeString!)", forKey: "LatLong")
                                UserDefaults.standard.synchronize()
                            }
                            else {
                                UserDefaults.standard.set("true", forKey: "IsError")
                                UserDefaults.standard.synchronize()
                                UserDefaults.standard.set("", forKey: "TimeStamp")
                                UserDefaults.standard.synchronize()
                                UserDefaults.standard.set("", forKey: "LatLong")
                                UserDefaults.standard.synchronize()
                            }
                        }
                    } // for end
                    }
                }
            }
            else {
                DispatchQueue.main.async {
                    let alertController = UIAlertController(title: "Lab Technician", message: "Connection Error", preferredStyle: .alert)
                    let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alertController.addAction(ok)
                    self.present(alertController, animated: true, completion: nil)
                }
                
            }
        }
    }

        }
    

extension UITextField {
    func addBottomBorder(){
//        let bottomLine = CALayer()
//        bottomLine.frame = CGRect(x: 0, y: self.frame.size.height - 1, width: self.frame.size.width, height: 1)
//        bottomLine.backgroundColor = UIColor.darkGray.cgColor
//        borderStyle = .none
//        layer.addSublayer(bottomLine)
//
      //  func underlined(color:UIColor){
               let border = CALayer()
               let width = CGFloat(1.0)
               border.borderColor = UIColor.darkGray.cgColor
               border.frame = CGRect(x: 0, y: self.frame.size.height - width, width:  self.frame.size.width, height: self.frame.size.height)
               border.borderWidth = width
               self.layer.addSublayer(border)
               self.layer.masksToBounds = true
          // }
           

    }
    
    func addBlueColor()
    {
        let bottomLine = CALayer()
        bottomLine.frame = CGRect(x: 0, y: self.frame.size.height - 1, width: self.frame.size.width, height: 1)
        bottomLine.backgroundColor = CGColor.init(red: 0.08, green: 0.31, blue: 0.56, alpha: 1.00)
        borderStyle = .none
        layer.addSublayer(bottomLine)
    }
    

    
    
}

//extension UIViewController {
//    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
//     //Check if there is any other text-field in the view whose tag is +1 greater than the current text-field on which the return key was pressed. If yes → then move the cursor to that next text-field. If No → Dismiss the keyboard
//     if let nextField = self.view.viewWithTag(textField.tag + 1) as? UITextField {
//     nextField.becomeFirstResponder()
//     } else {
//     textField.resignFirstResponder()
//     }
//     return false
//     }
//}

