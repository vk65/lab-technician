//
//  RadioButtonController.swift
//  Lab techinans
//
//  Created by Sambav on 27/06/22.
//

import UIKit

class RadioButtonController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    var buttonsArray: [UIButton]! {
          didSet {
              for b in buttonsArray {
                  b.setImage(UIImage(named: "radio_off"), for: .normal)
                  b.setImage(UIImage(named: "radio_on"), for: .selected)
              }
          }
      }
      var selectedButton: UIButton?
      var defaultButton: UIButton = UIButton() {
          didSet {
              buttonArrayUpdated(buttonSelected: self.defaultButton)
          }
      }

      func buttonArrayUpdated(buttonSelected: UIButton) {
          for b in buttonsArray {
              if b == buttonSelected {
                  selectedButton = b
                  b.isSelected = true
              } else {
                  b.isSelected = false
              }
          }
      }
}
