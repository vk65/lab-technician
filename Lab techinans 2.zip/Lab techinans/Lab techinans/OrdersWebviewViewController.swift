//
//  OrdersWebviewViewController.swift
//  Lab Technician
//
//  Created by Sambav on 01/07/22.
//

import UIKit
import WebKit

class OrdersWebviewViewController: UIViewController, WKNavigationDelegate {
var orders = OrdersViewController()
    @IBOutlet weak var imageLbl: UILabel!
    @IBOutlet weak var ordersWebview: WKWebView!
    var url:String?
    let activityIndicator = ActivityIndicator()
    override func viewDidLoad() {
        super.viewDidLoad()
        ordersWebview.navigationDelegate = self;
        ordersWebview.uiDelegate = self
        ordersWebview.contentMode = .scaleAspectFit
        ordersWebview.sizeToFit()
        ordersWebview.autoresizesSubviews = true
        loadDetailsPage()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func loadDetailsPage()
    {
        ordersWebview.isHidden = false
       // let uid = UserDefaults.standard.string(forKey: "userID") ?? ""
        guard let myBlog = url else{return}
        //"https://web.stanford.edu/class/archive/cs/cs161/cs161.1168/lecture4.pdf"
        print("\(String(describing: myBlog))")
        ordersWebview.load(URLRequest(url: URL(string: myBlog)!))
        let fileArray = myBlog.components(separatedBy: "/")
        let finalFileName = fileArray.last
        imageLbl.text = "\(String(describing: finalFileName ?? ""))"
        self.view.addSubview(ordersWebview)
        }
    
    public func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
     if (error as NSError).code == -999 {
        return
     }
     print(error)
    }
}

extension OrdersWebviewViewController: WKUIDelegate {

    /**
     * Force all popup windows to remain in the current WKWebView.
     * By default, WKWebView is blocking new windows from being created
     * ex <a href="link" target="_blank">text</a>.
     * This code catches those popup windows and displays them in the current WKWebView.
     */
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {

        // open in current view
        webView.load(navigationAction.request)

        // don't return a new view to build a popup into (the default behavior).
        return nil;
    }
}

